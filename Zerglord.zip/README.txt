I do not have a config yet for this bot.
You can change certain aspects of how it plays using the variables defined at the start.

If you want to run it locally against a default AI or play against it yourself
you will need to open Zerglord.py and navigate to run_locally()
In their you can edit the launch code and set it to play against whatever
default AI you want or against yourself. You can also change the number in the for
loop to change the number of matches that will run.

For matches against other bots just use the ladder manager.

I plan to add a config in the future.